package com.zybooks.weighttracker;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SmsActivity extends AppCompatActivity {

    //status label at bottom of the screen
    private TextView tvStatus;

    //ActivityResult API wrapper for single permission request
    private final ActivityResultLauncher<String> smsRequest =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(),
                    granted -> updateLabel());  //callback refresh UI

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        tvStatus = findViewById(R.id.tvSmsStatus);
        Button btn = findViewById(R.id.btnGrantSms);

        // launches the system permission dialog when the button is tapped
        btn.setOnClickListener(v ->
                smsRequest.launch(Manifest.permission.SEND_SMS));

        //shows initial state
        updateLabel();
    }

    //updates the status TextView on current permission state
    private void updateLabel() {
        boolean granted = ContextCompat.checkSelfPermission(
                this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
        tvStatus.setText(granted
                ? R.string.sms_status_granted // "Permission status granted"
                : R.string.sms_status_unknown); //"Permission status unknown"
    }
}
