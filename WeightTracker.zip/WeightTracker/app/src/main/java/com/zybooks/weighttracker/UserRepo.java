package com.zybooks.weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.security.MessageDigest;

/**
 * small repository that will hide raw SQL from the Activities
 * handles registering a user and validating credentials
 */

public class UserRepo {
    private final DbHelper helper;

    public UserRepo(Context ctx) {
        this.helper = new DbHelper(ctx);
    }

    ///registers a new username with a SHA-256 password hash
    public long register(String username, String password) {
        ContentValues cv = new ContentValues();
        cv.put("username", username.trim());
        cv.put("password_hash", sha256(password));

        SQLiteDatabase db = helper.getWritableDatabase();
        return db.insert(DbHelper.T_USERS, null, cv);
    }

    public long getUserIdIfValid(String username, String password) {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT id, password_hash FROM " + DbHelper.T_USERS + " WHERE username=?",
                new String[]{username}
        );
        try {
            if (c.moveToFirst()) {
                String storedHash = c.getString(1);
                if (storedHash.equals(sha256(password))) {
                    return c.getLong(0);
                }
            }
            return -1;
        } finally {
            c.close();
        }
    }

    public long getUserIDIfValid(String username, String password) {
        return getUserIdIfValid(username, password);
    }

    public boolean userExists(String username) {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT 1 FROM " + DbHelper.T_USERS + " WHERE username=?",
                new String[]{username}
        );
        try {
            return c.moveToFirst();
        } finally {
            c.close();
        }
    }
    ///simple SHA-256 password hashing
    private static String sha256(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] b = md.digest(s.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte x : b) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Exception e) {
            return s;
        }
    }
}
