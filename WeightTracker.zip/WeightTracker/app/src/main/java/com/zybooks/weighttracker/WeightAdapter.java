package com.zybooks.weighttracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.ViewHolder> {

    //listener interface lets the activity decide what to do based on users actions
    public interface OnItemActionListener {
        void onDelete(WeightRepo.WeightRow row);
        void onEdit(WeightRepo.WeightRow row);
    }
    //backing list for grid
    private final List<WeightRepo.WeightRow> items = new ArrayList<>();
    //callback
    private final OnItemActionListener listener;

    public WeightAdapter(OnItemActionListener listener) {
        this.listener = listener;
    }

    public void submit(List<WeightRepo.WeightRow> data) {
        items.clear();
        items.addAll(data);
        notifyDataSetChanged();
    }

    @NonNull @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int vt) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_weight, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int pos) {
        WeightRepo.WeightRow r = items.get(pos);
        //bind label fields
        h.tvDate.setText(r.date);
        h.tvWeight.setText(String.format(Locale.US, "%.0f lb", r.lb));

        //delete button forwards the event
        h.btnDelete.setOnClickListener(v -> listener.onDelete(r));

        //tapping the card lets users edit in a dialog
        h.itemView.setOnClickListener(v -> listener.onEdit(r));
    }

    @Override public int getItemCount() { return items.size(); }

    //small holder to cache views for each card
    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvDate, tvWeight;
        ImageButton btnDelete;
        ViewHolder(View item) {
            super(item);
            tvWeight = item.findViewById(R.id.tvWeight);
            tvDate = item.findViewById(R.id.tvDate);
            btnDelete = item.findViewById(R.id.btnDelete);
        }
    }
}