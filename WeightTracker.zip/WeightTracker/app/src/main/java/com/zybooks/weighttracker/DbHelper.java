package com.zybooks.weighttracker;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * DbHelper
 * Central place to create and upgrade local SQLite database
 * users; stores login credentials
 * weights; stores weight entries for each user
 */

public class DbHelper extends SQLiteOpenHelper {

    //name and version lets Android handle DB file and when to call onUpgrade
    public static final String DB_NAME = "weighttracker.db";
    private static final int DB_VERSION = 1;

    //table names as constants this will avoid typos in SQL
    public static final String T_USERS = "users";
    public static final String T_WEIGHTS = "weights";

    public DbHelper(Context ctx) {
        super(ctx, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        //SQLite foreign keys are off by default so this turn them on for connection
        db.setForeignKeyConstraintsEnabled(true);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        //users table, unique username and based password for basic authentication
        db.execSQL(
                "CREATE TABLE " + T_USERS + " (" +
                " id INTEGER PRIMARY KEY AUTOINCREMENT," +
                " username TEXT UNIQUE NOT NULL," +
                " password_hash TEXT NOT NULL" +
                ")"
        );

        //weight table, each row belongs to a user
        //using TEXT ISO dat to keep it sortable
        db.execSQL(
                "CREATE TABLE " + T_WEIGHTS + " (" +
                " id INTEGER PRIMARY KEY AUTOINCREMENT," +
                " user_id INTEGER NOT NULL," +
                " entry_date TEXT NOT NULL," +
                " weight_lb REAL NOT NULL," +
                " note TEXT," +
                "FOREIGN KEY(user_id) REFERENCES " + T_USERS + "(id) ON DELETE CASCADE" +
                ")"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        //drop and recreate strategy
        db.execSQL("DROP TABLE IF EXISTS " + T_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + T_USERS);
        onCreate(db);

    }
}