package com.zybooks.weighttracker;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton; //FAB

import java.util.List;

public class DataActivity extends AppCompatActivity implements WeightAdapter.OnItemActionListener {

    private long userId;
    private WeightRepo repo;
    private WeightAdapter adapter;

    /// triggers SMS demo
    private static final double GOAL_WEIGHT_LB = 130;

    /// store a message while requesting permission, send if granted
    private String pendingSmsMessage;

    /// registers a permission request launcher using modern Activity Result API
    private final ActivityResultLauncher<String> requestSmsPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted && pendingSmsMessage != null) {
                    sendSmsNow(pendingSmsMessage);
                } else {
                    ///if permission is denied app continues working and skips SMS
                    pendingSmsMessage = null;
                    Toast.makeText(this, "SMS permission denied. Continuing without SMS.", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data); // inflates activity_data.xml

        //resolve login in user id
        userId = getSharedPreferences("wt", MODE_PRIVATE).getLong("user_id", -1);
        if (userId <= 0) {
            Toast.makeText(this, "No user in session. Please log in again.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        //repo and adapter setup
        repo = new WeightRepo(this);
        adapter = new WeightAdapter(this);

        RecyclerView rv = findViewById(R.id.rvWeights); //list container in XML
        rv.setLayoutManager(new GridLayoutManager(this, 2)); //two column grid
        rv.setAdapter(adapter); //stub adapter

        //load data initially
        refreshList();

        //add new entry short press
        FloatingActionButton fab = findViewById(R.id.fabAdd);
        fab.setOnClickListener(v -> showAddOrEditDialog(null));
    }

    private void refreshList() {
        List<WeightRepo.WeightRow> rows = repo.listForUser(userId);
        adapter.submit(rows);
    }

    // ADD / EDIT DIALOGS
    private void showAddOrEditDialog(WeightRepo.WeightRow row) {
        boolean editing = (row != null);

        //simple vertical form with two inputs (date, weight)
        EditText etDate = new EditText(this);
        etDate.setHint("YYYY-MM-DD");
        etDate.setInputType(InputType.TYPE_CLASS_DATETIME);

        EditText etLb = new EditText(this);
        etLb.setHint("Weight lb");
        etLb.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

        if (editing) {
            etDate.setText(row.date);
            etLb.setText(String.valueOf((int) row.lb));
        }

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        form.setPadding(pad, pad, pad, pad);
        form.addView(etDate);
        form.addView(etLb);

        new AlertDialog.Builder(this)
                .setTitle(editing ? "Edit Entry" : "Add Entry")
                .setView(form)
                .setPositiveButton(editing ? "Update" : "Save", (d, w) -> {
                    String date = etDate.getText().toString().trim();
                    String weightStr = etLb.getText().toString().trim();

                    if (date.isEmpty() || weightStr.isEmpty()) {
                        Toast.makeText(this, "Please enter date and weight.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    double lb;
                    try {
                        lb = Double.parseDouble(weightStr);
                    } catch (NumberFormatException nfe) {
                        Toast.makeText(this, "Enter a valid number weight.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (editing) {
                        repo.update(row.id, date, lb, row.note);
                    } else {
                        repo.add(userId, date, lb, "");
                        //optional SMS trigger, reached/under goal
                        maybeSendSms("New weight logged: " + (int) lb + " lb");
                        if (lb <= GOAL_WEIGHT_LB) {
                            maybeSendSms("Congrats! You reached your goal weight (" + (int) lb + " lb).");
                        }
                    }
                    refreshList();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    //ADAPTOR CALLBACKS DELETE / EDIT
    @Override
    public void onDelete(WeightRepo.WeightRow row) {
        new AlertDialog.Builder(this)
                .setMessage("Delete this entry?")
                .setPositiveButton("Delete", (d, w) -> {
                    repo.delete(row.id);
                    refreshList();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    public void onEdit(WeightRepo.WeightRow row) {
        showAddOrEditDialog(row);
    }

    //SMS PERMISSION AND SEND

    private void maybeSendSms(String message) {
        //keep one pending message at a time
        pendingSmsMessage = message;

        //if already granted send immediately
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            sendSmsNow(message);
            pendingSmsMessage = null;
        } else {
            //ask the user on result requestSmsPermission will run
            requestSmsPermission.launch(Manifest.permission.SEND_SMS);
        }
    }

    //send the SMS using the platform SmsManager
    private void sendSmsNow(String message) {
        try {
            //use a test number for emulator on my device
            String phone = "1234567890";
            SmsManager.getDefault().sendTextMessage(phone, null, message, null, null);
            Toast.makeText(this, "SMS sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            //covers emulator limitations
            Toast.makeText(this, "SMS could not be sent on this device.", Toast.LENGTH_SHORT).show();
        }
    }
}
