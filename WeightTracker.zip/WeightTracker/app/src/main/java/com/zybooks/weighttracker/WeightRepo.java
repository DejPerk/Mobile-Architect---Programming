package com.zybooks.weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class WeightRepo {

    private final DbHelper helper;

    public WeightRepo(Context ctx) {
        helper = new DbHelper(ctx);
    }

    //adds a new weight row for a user and returns new  row id
    public long add(long userId, String isoDate, double lb, String note) {
        ContentValues cv = new ContentValues();
        cv.put("user_id", userId);
        cv.put("entry_date", isoDate);
        cv.put("weight_lb", lb);
        cv.put("note", note);
        SQLiteDatabase db = helper.getWritableDatabase();
        return db.insert(DbHelper.T_WEIGHTS, null, cv);
    }

    //updates existing row id and return number of rows changed
    public int update(long id, String isoDate, double lb, String note) {
        ContentValues cv = new ContentValues();
        cv.put("entry_date", isoDate);
        cv.put("weight_lb", lb);
        cv.put("note", note);
        return helper.getWritableDatabase()
                .update(DbHelper.T_WEIGHTS, cv, "id=?", new String[]{String.valueOf(id)});
    }

    //deletes a row by id and returns number of rows removed
    public int delete(long id) {
        return helper.getWritableDatabase()
                .delete(DbHelper.T_WEIGHTS, "id=?", new String[]{String.valueOf(id)});
    }

    //lists all rows for a user
    public List<WeightRow> listForUser(long userId) {
        List<WeightRow> out = new ArrayList<>();

        Cursor c = helper.getReadableDatabase().rawQuery(
                "SELECT id, entry_date, weight_lb, note " +
                        "FROM " + DbHelper.T_WEIGHTS +
                        " WHERE user_id=? ORDER BY entry_date DESC",
                new String[]{String.valueOf(userId)});
        try {
            //iterate each row and map columns
            while (c.moveToNext()) {
                long id = c.getLong(0);
                String date = c.getString(1);
                double lb = c.getDouble(2);
                String note = c.getString(3);

                out.add(new WeightRow(id, date, lb, note));
            }
        } finally {
            //close cursor to avoid leaks
            c.close();
        }
        return out;
    }

    public static class WeightRow {
                public final long id;
                public final String date;
                public final double lb;
                public final String note;

                public WeightRow(long id, String date, double lb, String note) {
                    this.id = id;
                    this.date = date;
                    this.lb = lb;
                    this.note = note;
                }
            }
        }