package com.zybooks.weighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    //input fields bound to activity_login.xml
    private EditText etUser, etPass;
    //data access object for user CRUD validation
    private UserRepo userRepo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //inflate login layout
        setContentView(R.layout.activity_login);
        //bind views
        etUser = findViewById(R.id.etUsername);
        etPass = findViewById(R.id.etPassword);
        //Init repository
        userRepo = new UserRepo(this);
        //Sign in button
        findViewById(R.id.btnLogin).setOnClickListener(v -> signIn());
        //create account button
        findViewById(R.id.btnCreate).setOnClickListener(v -> createAccount());
    }

    private void signIn() {
        String u = etUser.getText().toString().trim();
        String p = etPass.getText().toString();

        long uid = userRepo.getUserIdIfValid(u, p);
        if (uid > 0) {
            //persist who is logged in
            getSharedPreferences("wt", MODE_PRIVATE).edit()
                    .putLong("user_id", uid)
                    .apply();

            //navigate to the data grid
            startActivity(new Intent(this, DataActivity.class));
        } else {
            Toast.makeText(this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
        }
    }
    private void createAccount() {
        String u = etUser.getText().toString().trim();
        String p = etPass.getText().toString();

        //basic validation
        if (u.isEmpty() || p.isEmpty()) {
            Toast.makeText(this, "Enter username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        //preventing duplicated usernames
        if (userRepo.userExists(u)) {
            Toast.makeText(this, "Username already exists.", Toast.LENGTH_SHORT).show();
            return;
        }

        //create user
        long id = userRepo.register(u, p);
        if (id > 0) {
            //auto login newly created user
            getSharedPreferences("wt", MODE_PRIVATE).edit()
                    .putLong("user_id", id)
                    .apply();

            //navigate to data grid
            startActivity(new Intent(this, DataActivity.class));
        } else {
            Toast.makeText(this, "Could not create account. Try a different username.", Toast.LENGTH_SHORT).show();
        }
    }
}